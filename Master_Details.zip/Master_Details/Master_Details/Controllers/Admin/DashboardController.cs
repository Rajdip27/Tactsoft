﻿using Microsoft.AspNetCore.Mvc;

namespace Master_Details.Controllers.Admin
{
    public class DashboardController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
