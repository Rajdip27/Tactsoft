﻿using Master_Details.Models;
using Master_Details.Service.Base;

namespace Master_Details.Service
{
    public interface IPurchaseSerivce:IBaseService<Purchase>
    {
    }
}
