﻿namespace Master_Details.Models.Base
{
    public class MasterEntity
    {
        public long Id { get; set; }
    }
}
