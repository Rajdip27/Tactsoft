﻿namespace Tactsoft.Application.Models.Auth;

public class RegistrationResponse
{
    public long UserId { get; set; }
}
