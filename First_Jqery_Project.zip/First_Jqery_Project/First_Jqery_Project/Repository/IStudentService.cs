﻿using First_Jqery_Project.Models;
using First_Jqery_Project.Repository.Base;

namespace First_Jqery_Project.Repository
{
    public interface IStudentService:IBaseService<Student>
    {
    }
}
