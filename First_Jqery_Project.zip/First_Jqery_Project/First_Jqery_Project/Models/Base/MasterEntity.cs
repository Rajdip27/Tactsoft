﻿namespace First_Jqery_Project.Models.Base
{
    public class MasterEntity
    {
        public long Id { get; set; }
    }
}
